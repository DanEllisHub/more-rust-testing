fn main() {
    // Sink 
    let b = Box::new(42);
    other_actions_not_related_to_the_Box();
}