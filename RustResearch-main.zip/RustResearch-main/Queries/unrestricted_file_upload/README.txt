Note for Devs, this query is the Dangerous_File_Extension query.
